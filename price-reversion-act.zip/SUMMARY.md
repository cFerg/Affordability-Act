# Summary

Problem → wages vs. prices; Solution → WIV/RACV caps; Offer integrity; Vehicles/Insurance/HOAs/Timeshares; Taxes aligned.
