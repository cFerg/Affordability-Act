# Price Reversion Act

Each section is its own page for focused review. The compiled bill pulls from these pages.
