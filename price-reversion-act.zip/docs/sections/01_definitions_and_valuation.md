# Definitions & Valuation

Plain-English WIV, RACV, lesser-of, PV (NM/RTB), guardrails, audits, VRB.