# Single-Family & Land Reset

Sales cap = Applicable Value + NM. Land improvements limited; trusts/owner-occupant carve-ins.