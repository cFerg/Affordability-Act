# Rezoned Properties

Original-zone pegging; development-cost add; rezoning dividend to housing funds.