# Blight, Neglect & Trusts

Vacancy timelines; junkyard surcharges; land bank; minors in trust protected; maintenance duty.