# Multi-Unit Properties

Occupancy floor + vacancy surtax; unit allocation (sq ft/rooms); Rent/Mortgage Adjustments.