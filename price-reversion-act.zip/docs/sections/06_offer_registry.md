# Offer Registry & Anti-Bot

Priority ladder → timestamp; no above-cap tie-breaks; pre-verification; anti-bot; logs; whistleblower.