# Payment Integrity (All Contracts)

Cash-only ban; no-fee digital option; receipts; posting credit; surcharge caps; STR off-platform cash ban.