# Timeshares

RAV→IAV; NM-TS; owner credits; fee caps; exit/buyback; points devaluation controls.