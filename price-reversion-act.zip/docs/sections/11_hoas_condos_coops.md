# HOAs / Condos / Co-ops

Assessment cap (wage/cost); reserve study; owner votes; conflicts/bids; investor limits.