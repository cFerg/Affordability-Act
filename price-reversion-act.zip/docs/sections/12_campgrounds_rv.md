# Campgrounds & RV Parks

Cost-based nightly rate; wage-indexed increases; no junk resort fees; ≥30 days = tenancy.