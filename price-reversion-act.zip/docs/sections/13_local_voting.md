# Local Voting Integrity

Single-domicile voting; ban non-resident property-owner ballots; residency minima.