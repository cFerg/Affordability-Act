# Property Taxes

Assess at lower of WIV or RACV; revenue-neutral rollback; circuit-breaker; homestead; vehicle AVV.