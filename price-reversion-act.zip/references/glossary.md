# Glossary

OPP, WIV, RACV, PV (NM/RTB); OTP/VWIV/RACVV/AVV/NMV; RAV/IAV; Beneficial Owner.
